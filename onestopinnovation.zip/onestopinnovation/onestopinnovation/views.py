from django.shortcuts import render
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.template import Context, loader
from django.views.generic.base import TemplateView

def pitch(request):
	return render_to_response('pitchintro.html',)

def invest(request):
	return render_to_response('investintro.html',)

def jobs(request):
	return render_to_response('jobsintro.html',)

def resources(request):
	return render_to_response('resourcesintro.html')

def projects(request):
	return render_to_response('startprojects.html')

def freeresources(request):
	return render_to_response('freeresources.html')

def events(request):
	return render_to_response('events.html')