/* global window */
window.jQuery = window.$ = require('jquery');

const $ = window.$;

require('bootstrap');

$(() => {
    console.log('document ready');
});
